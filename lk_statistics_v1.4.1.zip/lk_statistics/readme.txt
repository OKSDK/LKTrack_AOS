﻿步骤一：jar包及manifest配置

     1.将 lk_statistics_vx.x.x.jar 和 android-support-v4.jar拷贝到游戏对应的libs目录下，Androidmanifest.text中的权限部分拷贝到游戏Androidmenifest.xml中
     
     注意：如果游戏本身有android-support-v4.jar，直接用游戏的即可，无需再次拷贝。

步骤二：工程assets配置

     1.对于在中国大陆地区发行的游戏，接入统计SDK，将assets_china目录下的文件拷贝到游戏对应的assets目录下，对于非中国大陆地区发行的游戏，需选择对应地区的配置文件到assets目录下。


步骤三：google服务工程的依赖

     1.对于在非中国大陆地区发行的游戏，接入统计SDK需要依赖 LK_Google_Service6171000 
     
     2.游戏工程需在Androidmanifest.xml中配置上<meta-data android:name="com.google.android.gms.version" android:value="@integer/google_play_services_version" />
      否则统计不到google广告ID 


步骤四：调用对应接口
     
      安装github上的文档逐个调用接口即可。

注意：如果游戏本身有更新版本的google serveice服务工程，直接用游戏最新的工程即可。