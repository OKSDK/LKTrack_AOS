﻿中国大陆：
   
    1.将 lk_statistics_vx.x.x.jar 和 android-support-v4.jar拷贝到游戏对应的libs目录下，

      Androidmanifest.text中的权限部分拷贝到游戏Androidmenifest.xml中
     
     注意：如果游戏本身有android-support-v4.jar，直接用游戏的即可，无需再次拷贝。

    2.将assets_china目录下的文件拷贝到游戏对应的assets目录下。

    3.按照github上的文档逐个调用接口即可。



海外：
   
   1.将 lk_statistics_vx.x.x_no_imei.jar 和 android-support-v4.jar拷贝到游戏对应的libs目录下，
 
     Androidmanifest.text中的权限部分拷贝到游戏Androidmenifest.xml中
     
     注意：如果游戏本身有android-support-v4.jar，直接用游戏的即可，无需再次拷贝。

   2.选择对应地区的配置文件到游戏对应的assets目录下, 如北美地区选择assets_north_america目录下的文件。

   3.游戏工程需要依赖 LK_Google_Service6171000，并在游戏的 Androidmanifest.xml中配置上
   
         <meta-data android:name="com.google.android.gms.version" android:value="@integer/google_play_services_version" />

     否则获取不到google广告ID

     注意：如果游戏本身有更新版本的google serveice服务工程，直接用游戏最新的工程即可。
   
   4.按照github上的文档逐个调用接口即可。



说明：lk_statistics_vx.x.x.jar 和 lk_statistics_vx.x.x_no_imei.jar 的区别只是前者有自动获取imei，

      而后者不会获取imei，要想统计imei只能通过setIMEI方法将imei设置进去。

