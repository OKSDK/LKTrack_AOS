﻿1.对于在中国大陆地区发行的游戏，接入统计SDK，只需要将 lk_statistics_vx.x.x.jar拷贝到游戏对应的libs目录下，assets_china目录下的文件拷贝到
  游戏对应的assets目录下，Androidmanifest.text中的权限部分拷贝到游戏Androidmenifest.xml中, 然后参考文档调用对应事件即可。

2.对于在非中国大陆地区发行的游戏，接入统计SDK 做完上述 1 后还需要依赖 LK_Google_Service6171000 这个工程并且在Androidmanifest.xml中配置上
    <meta-data android:name="com.google.android.gms.version" android:value="@integer/google_play_services_version" /> 否则统计不到google广告ID 

注意：如果游戏本身有更新版本的google serveice服务工程，可直接用游戏最新的工程即可。